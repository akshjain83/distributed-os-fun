/* This file is auto generated, version 53~14.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#53~14.04.1 SMP Sat Jan 30 17:10:48 PST 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
