#define UTS_RELEASE "3.19.0-47-generic"
#define UTS_UBUNTU_RELEASE_ABI 47
